import pymongo as pym
client = pym.MongoClient('mongodb+srv://edupanpan.sa270.mongodb.net/',
                         27017, connect = False, username = 'edupanpan', password = 'Edu33827..')